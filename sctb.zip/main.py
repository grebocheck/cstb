import time

import settings
import telebot
from loge import *
from telebot import types
from data_base import *

bot = telebot.TeleBot(settings.TOKEN)
statuss = ['creator', 'administrator', 'member']

cance_text = "Отменить ❌"
continue_text = "Пропустить 👍"
suply_text = "Проверить подписку на канал для награды ✅"

cance_button = types.KeyboardButton(cance_text)
continue_markup = types.ReplyKeyboardMarkup()
continue_markup = continue_markup.row(types.KeyboardButton(continue_text),
                                      cance_button)

suply_markup = types.ReplyKeyboardMarkup()
suply_markup = suply_markup.row(types.KeyboardButton(suply_text))

del_markup = types.ReplyKeyboardRemove()


# Стартовая команда
@bot.message_handler(commands=['start'])
def starter(message):
    try:
        if new_user(message.from_user.id):
            bot.send_message(message.chat.id, """Приветствую в нашем боте 🥳

Введите *username* своего друга который привел вас и вы оба получите боннус в виде 1 безплатного аккаунта""",
                            parse_mode='markdown', reply_markup=continue_markup)
            bot.register_next_step_handler(message, me_invite)
        else:
            bot.send_message(message.chat.id, """Приветствую в нашем боте 🥳
        
Вы уже были зарегистрированы""", reply_markup=suply_markup)
    except Exception as ex:
        print(ex)

# Ввод реферала
def me_invite(message):
    try:
        if message.text != cance_text:
            if message.text != continue_text:
                try:
                    ref_username = message.text.replace("@", "")
                    my_inv_id = get_inviter(ref_username)
                    if my_inv_id == "None":
                        bot.send_message(message.chat.id, "Увы данного пользователя не обнаруженно, попробуйте ввести еще раз "
                                                        "😥",
                                        reply_markup=continue_markup)
                        bot.register_next_step_handler(message, me_invite)
                    else:
                        data.append([message.from_user.id, message.from_user.username, False, ref_username])
                        save_json(data)
                        bot.send_message(my_inv_id, f"Вы привели в бота реферала за что получаете 🔥 `{get_acc()}`",
                                        parse_mode='markdown')
                        bot.send_message(message.chat.id,
                                        f"Поздравляем вот ваша награда по реферальной програме 🔥 `{get_acc()}`",
                                        parse_mode='markdown', reply_markup=suply_markup)
                except Exception as ex:
                    print(ex)
                    log_err("Кто то вызвал исключение о недопустимом типе данных при вводе ника")
                    bot.send_message(message.chat.id, "Введите пожалуйста все же ник"
                                                    "😥",
                                    reply_markup=continue_markup)
                    bot.register_next_step_handler(message, me_invite)
            else:
                data.append([message.from_user.id, message.from_user.username, False, "None"])
                save_json(data)
                bot.send_message(message.chat.id, f"Поздравляем вы успешно зарегистрировались в боте 😇",
                                reply_markup=suply_markup)
        else:
            bot.send_message(message.chat.id, "Регистрация отменена 🙁")
    except Exception as ex:
        print(ex)


# команда рассылки
@bot.message_handler(commands=['send'])
def pulse_one(message):
    try:
        if message.from_user.username in settings.ADMINS:
            bot.send_message(message.chat.id, "Введите сообщение которое нужно розослать всем пользователям бота 😇",
                            reply_markup=del_markup)
            bot.register_next_step_handler(message, pulse_two)
        else:
            bot.send_message(message.chat.id, f"В доступе отказано ❌")
    except Exception as ex:
        print(ex)


def pulse_two(message):
    try:
        for a in data:
            time.sleep(1)
            try:
                bot.copy_message(a[0], message.chat.id, message.message_id)
            except Exception as ex:
                print(ex)
                log_err("Ошибка при отправке сообщения розсылки ❌")
    except Exception as ex:
        print(ex)


# Проверка подписки на канал
@bot.message_handler(content_types='text')
def suply_subscrybe(message):
    try:
        if message.text == suply_text:
            if not new_user(message.from_user.id):
                res = 0
                for i in statuss:
                    if i == bot.get_chat_member(settings.GROUP_ID, message.from_user.id).status:
                        res += 1
                        if subsribe(message.from_user.id):
                            bot.send_message(message.chat.id, f"Поздравляем вот ваша награда за подписку 🥳 `{get_acc()}`",
                                            parse_mode='markdown', reply_markup=del_markup)
                        else:
                            bot.send_message(message.chat.id, f"Вы уже получили награду 🤨 {settings.GROUP_LINK}", reply_markup=del_markup)
                if res == 0:
                    bot.send_message(message.chat.id, f"Вы еще не подписаны на канал 🤨 {settings.GROUP_LINK}")
            else:
                bot.send_message(message.chat.id, f"Начните с регистрации в боте командой /start 😃 {settings.GROUP_LINK}")
        else:
            bot.send_message(message.chat.id, "Этой команды нету ❌")
    except Exception as ex:
        print(ex)


if __name__ == "__main__":
    bot.polling()
