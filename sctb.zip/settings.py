TOKEN = '5211807463:AAGDePzRBpj9k0A_YLZTkLQd8KfSARyuZqA'

ADMINS = ['andreyrazyn']

GROUP_ID = -1001219619337

GROUP_LINK = "https://t.me/stalcraft_ak"