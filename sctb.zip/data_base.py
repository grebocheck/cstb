import json
from loge import *


def save_json(data):
    with open('data.json', 'w') as fp:
        json.dump(data, fp)
    log_deb("Использована команда сохранения")


def load_json():
    with open('data.json', 'r') as fp:
        data = json.load(fp)
        log_deb("Использована команда загрузки")
        return data


try:
    data = load_json()
except:
    data = []
    save_json(data)


def new_user(user_id):
    user_id_data = []
    for a in data:
        user_id_data.append(a[0])
    if user_id not in user_id_data:
        return True
    else:
        return False


def get_inviter(username):
    inviter = "None"
    for a in range(len(data)):
        if data[a][1] == username:
            inviter = data[a][0]
    return inviter


def get_acc():
    with open('account_list.txt', 'r') as f:
        lines = f.readlines()
    account = lines[0]
    with open('account_list.txt', 'w') as f:
        f.writelines(lines[1:])
    log_deb(f"извлечен аккаунт {account}")
    return account


def subsribe(user_id):
    r = False
    for a in data:
        if a[0] == user_id:
            if a[2] == False:
                a[2] = True
                r = True
    save_json(data)
    return r
